<?php include 'header.php'; ?>


	<div class="page-content d-flex align-items-stretch">
        <!-- Side Navbar -->
        <nav class="side-navbar">
          <!-- Sidebar Header-->
          <div class="sidebar-header d-flex align-items-center">
            <div class="avatar"><img src="img/avatar-1.jpg" alt="..." class="img-fluid rounded-circle"></div>
            <div class="title">
              <h1 class="h4"><?php echo $_SESSION['username']; ?></h1>
              <p><?php echo $_SESSION['status']; ?></p>
            </div>
          </div>
          <!-- Sidebar Navidation Menus--><span class="heading">Main</span>
          <ul class="list-unstyled">
            <li> <a href="panel_penyewa.php"><i class="icon-home"></i>Home</a></li>
            <li> <a href="cari_kos.php"> <i class="icon-grid"></i>Cari Kos</a></li>
            <!-- <li> <a href="charts.html"> <i class="fa fa-bar-chart"></i>Charts </a></li> -->
            <li> <a href="form_penyewa.php"> <i class="icon-padnote"></i>Cek Kos</a></li>
            <li class="active"> <a href="account_penyewa.php"> <i class="icon-interface-windows"></i>Account</a></li>
          </ul>
        </nav>

		<div class="content-inner">
          <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Account</h2>
            </div>
          </header>
          <!-- Forms Section-->
          <section class="forms"> 
            <div class="container-fluid">
              <div class="row">
                <!-- Basic Form-->
                <div class="col-lg-12">
                  <div class="card">
                    <div class="card-header d-flex align-items-center">
                      <h3 class="h4">Data Diri Akun Anda</h3>
                    </div>
                    <div class="card-body">
                    <div class="card-close">
                    <div class="dropdown">
                        <button type="button" id="closeCard1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-ellipsis-v"></i></button>
                        <div aria-labelledby="closeCard1" class="dropdown-menu dropdown-menu-right has-shadow"><a href="#demo" class="dropdown-item edit" data-toggle="collapse" data-target="#demo"> <i class="fa fa-gear"></i>Edit</a></div>
                      </div>
                    </div>
                    <?php
						include '../php/connect.php';

						$user = $_SESSION['username'];

						$sql = "select * from user where id_user='$user'";
						$query = mysqli_query($con, $sql);
						$row = mysqli_fetch_array($query, MYSQLI_ASSOC);
						echo '
							<table class="table table-bordered">
							    <tr>
							        <td>Id_User</td>
							        <td>'.$row["id_user"].'</td>
							    </tr>
							    <tr>
							        <td>Password</td>
							        <td>'.$row["password"].'</td>
							    </tr>
							    <tr>
							        <td>E-Mail</td>
							        <td>'.$row["email"].'</td>
							    </tr>
							    <tr>
							        <td>Nama</td>
							        <td>'.$row["nama"].'</td>
							    </tr>
							    <tr>
							        <td>No Telp</td>
							        <td>'.$row["telp"].'</td>
							    </tr>
							    <tr>
							        <td>NIK</td>
							        <td>'.$row["NIK"].'</td>
							    </tr>
							    <tr>
							        <td>Alamat</td>
							        <td>'.$row["alamat"].'</td>
							    </tr>
							    <tr>
							        <td>Status</td>
							        <td>'.$row["status"].'</td>
							    </tr>	
							</table>
						';
					?>
                    </div>
                  </div>
                  <div class="collapse" id="demo">
                  	<div class="card">
                    <div class="card-header d-flex align-items-center">
                      <h3 class="h4">Edit Data Diri Akun Anda</h3>
                    </div>
                    <div class="card-body">
                    <div class="card-close">
                    </div>
                    <?php
						include '../php/connect.php';

						$user = $_SESSION['username'];

						$sql = "select * from user where id_user='$user'";
						$query = mysqli_query($con, $sql);
						$row = mysqli_fetch_array($query, MYSQLI_ASSOC);
						echo '
						<form action="../php/update_account.php?user='.$user.'" method="POST">
							<table class="table">
								<tr>
							        <td>Id User</td>
							        <td><input class="form-control" type="text" value="'.$row["id_user"].'" name="id_user"></input></td>
							    </tr>
							    <tr>
							        <td>password</td>
							        <td><input class="form-control" type="text" value="'.$row["password"].'" name="password"></input></td>
							    </tr>
							    <tr>
							        <td>E-Mail</td>
							        <td><input class="form-control" type="email" value="'.$row["email"].'" name="email"></input></td>
							    </tr>
							    <tr>
							        <td>Nama</td>
							        <td><input class="form-control" type="text" value="'.$row["nama"].'" name="nama"></input></td>
							    </tr>
							    <tr>
							        <td>No Telp</td>
							        <td><input class="form-control" type="text" value="'.$row["telp"].'" name="telp"></input></td>
							    </tr>
							    <tr>
							        <td>NIK</td>
							        <td><input class="form-control" type="text" value="'.$row["NIK"].'" name="nik"></input></td>
							    </tr>
							    <tr>
							        <td>Alamat</td>
							        <td><input class="form-control" type="text" value="'.$row["alamat"].'" name="alamat"></input></td>
							    </tr>
							    <tr>
							        <td colspan="2"><input value="Update" class="btn btn-success btn-block" type="submit"></td>
							    </tr>	
							</table>
						</form>
						';
					?>
                    </div>
                  </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

<?php include 'footer.php'; ?>