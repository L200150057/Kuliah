<?php include 'header.php' ?>

      <div class="page-content d-flex align-items-stretch">
        <!-- Side Navbar -->
        <nav class="side-navbar">
          <!-- Sidebar Header-->
          <div class="sidebar-header d-flex align-items-center">
            <div class="avatar"><img src="img/avatar-1.jpg" alt="..." class="img-fluid rounded-circle"></div>
            <div class="title">
              <h1 class="h4"><?php echo $_SESSION['username']; ?></h1>
              <p><?php echo $_SESSION['status']; ?></p>
            </div>
          </div>
          <!-- Sidebar Navidation Menus--><span class="heading">Main</span>
          <ul class="list-unstyled">
            <li> <a href="panel_pemilik.php"><i class="icon-home"></i>Home</a></li>
            <li class="active"> <a href="view_pemilik.php"> <i class="icon-grid"></i>View Data </a></li>
            <li> <a href="pelanggan.php"> <i class="icon-grid"></i>Pelanggan</a></li>
            <li> <a href="form_pemilik.php"> <i class="icon-padnote"></i>Input Data Kos </a></li>
            <li> <a href="account_pemilik.php"> <i class="icon-interface-windows"></i>Account</a></li>
          </ul>
        </nav>

		    <div class="content-inner">
          <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">View Data Kos Anda</h2>
            </div>
          </header>
          <section class="forms"> 
            <div class="container-fluid">
              <div class="data">
                <!-- Basic Form-->
                <div class="col-lg-12">
                      <?php

                        include '../php/connect.php';
                        $user = $_SESSION['username'];
                        $kos = $_GET['kos'];
                        $sql = "select * from data_kos where nama_kos='$kos'";
                        $query = mysqli_query($con, $sql);
                        while ($data = mysqli_fetch_array($query, MYSQLI_ASSOC)){
                          echo '
                          <div class="card">
                          <div class="card-header d-flex align-items-center">
                            <h3 class="h4">Edit Data Kos Anda</h3>
                          </div>
                          <div class="card-body">
                          <div class="card-close">
                          <div class="dropdown">
                              <button type="button" id="closeCard1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-ellipsis-v"></i></button>
                              <div aria-labelledby="closeCard1" class="dropdown-menu dropdown-menu-right has-shadow"><a href="#demo" class="dropdown-item edit" data-toggle="collapse" data-target="#demo"> <i class="fa fa-gear"></i>Edit</a></div>
                            </div>
                          </div>
                            <form action="../php/update_kos.php?kos='.$kos.'" method="POST">
                              <table class="table">
                                  <tr>
                                      <td>Nama Kos</td>
                                      <td><input class="form-control" type="text" value="'.$data["nama_kos"].'" name="nama"></input></td>
                                  </tr>
                                  <tr>
                                      <td>Alamat Kos</td>
                                      <td><input type="text" class="form-control" value="'.$data["alamat_kos"].'" name="alamat"></input></td>
                                  </tr>
                                  <tr>
                                      <td>Fasilitas Kos</td>
                                      <td><input class="form-control" type="text" value="'.$data["fasilitas"].'" name="fasilitas"></input></td>
                                  </tr>
                                  <tr>
                                      <td>Kamar Mandi</td>
                                      <td><input class="form-control" type="text" value="'.$data["wc"].'" name="wc"></input></td>
                                  </tr>
                                  <tr>
                                      <td>Harga Kos 1 Bulan</td>
                                      <td><input class="form-control" type="text" value="'.$data["1bln"].'" name="1bln"></input></td>
                                  </tr>
                                  <tr>
                                      <td>Harga Kos 6 Bulan</td>
                                      <td><input class="form-control" type="text" value="'.$data["6bln"].'" name="6bln"></input></td>
                                  </tr>
                                  <tr>
                                      <td>Harga Kos 1 Tahun</td>
                                      <td><input class="form-control" type="text" value="'.$data["1thn"].'" name="1thn"></input></td>
                                  </tr>
                                  <tr>
                                      <td colspan="2"><input value="Update" class="btn btn-success btn-block" type="submit"></td>
                                  </tr> 
                              </table>
                            </form>
                            </div>
                            </div>
                          ';  
                        }                      
                      ?>                    
                </div>
              </div>
            </div>
          </section>

<?php include 'footer.php' ?>