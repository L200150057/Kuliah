<?php include 'header.php' ?>

      <div class="page-content d-flex align-items-stretch">
        <!-- Side Navbar -->
        <nav class="side-navbar">
          <!-- Sidebar Header-->
          <div class="sidebar-header d-flex align-items-center">
            <div class="avatar"><img src="img/avatar-1.jpg" alt="..." class="img-fluid rounded-circle"></div>
            <div class="title">
              <h1 class="h4"><?php echo $_SESSION['username']; ?></h1>
              <p><?php echo $_SESSION['status']; ?></p>
            </div>
          </div>
          <!-- Sidebar Navidation Menus--><span class="heading">Main</span>
          <ul class="list-unstyled">
            <li> <a href="panel_pemilik.php"><i class="icon-home"></i>Home</a></li>
            <li> <a href="view_pemilik.php"> <i class="icon-grid"></i>View Data </a></li>
            <li  class="active"> <a href="pelanggan.php"> <i class="icon-grid"></i>Data Penyewa</a></li>
            <li> <a href="form_pemilik.php"> <i class="icon-padnote"></i>Input Data Kos </a></li>
            <li> <a href="account_pemilik.php"> <i class="icon-interface-windows"></i>Account</a></li>
          </ul>
        </nav>

		    <div class="content-inner">
          <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Orang Yang Menyewa Kos Anda</h2>
            </div>
          </header>
          <section class="forms"> 
            <div class="container-fluid">
              <div class="row">
                <!-- Basic Form-->
                <div class="col-lg-12">
                	<div class="card">
                    	<div class="card-body">
                    	<table class="table table-bordered">
                    		<tr>
                    			<td>Nama</td>
                    			<td>E-mail</td>
                    			<td>No Telp</td>
                    			<td>Alamat</td>
                    			<td>Menyewa Kos</td>
                    		</tr>
                      <?php

                        include '../php/connect.php';
                        $user = $_SESSION['username'];

                        $sql = "select id_penyewa, id_kos from transaksi where id_pemilik='$user'";
                        $query = mysqli_query($con, $sql);
                        while ($data = mysqli_fetch_array($query, MYSQLI_ASSOC)){

                        	$id_penyewa = $data['id_penyewa'];
                        	$id_kos = $data['id_kos'];
                        	$sql1 = "select * from user where id_user='$id_penyewa'";
                        	$sql2 = "select nama_kos from data_kos where id_kos='$id_kos'";
                        	$query1 = mysqli_query($con, $sql1);
                        	$query2 = mysqli_query($con, $sql2);
                        	$data2 = mysqli_fetch_array($query2, MYSQLI_ASSOC);
                        	$data1 = mysqli_fetch_array($query1, MYSQLI_ASSOC);

                        	echo '
                        		<tr>
	                    			<td>'.$data1['nama'].'</td>
	                    			<td>'.$data1['email'].'</td>
	                    			<td>'.$data1['telp'].'</td>
	                    			<td>'.$data1['alamat'].'</td>
	                    			<td>'.$data2['nama_kos'].'</td>
                    			</tr>
                        	';

                        }
                        

                      ?>
                      	</table>
                		</div>
                    </div>        
                </div>
              </div>
            </div>
          </section>

<?php include 'footer.php' ?>