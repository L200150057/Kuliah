<?php include 'header.php' ?>

      <div class="page-content d-flex align-items-stretch">
        <!-- Side Navbar -->
        <nav class="side-navbar">
          <!-- Sidebar Header-->
          <div class="sidebar-header d-flex align-items-center">
            <div class="avatar"><img src="img/avatar-1.jpg" alt="..." class="img-fluid rounded-circle"></div>
            <div class="title">
              <h1 class="h4"><?php echo $_SESSION['username']; ?></h1>
              <p><?php echo $_SESSION['status']; ?></p>
            </div>
          </div>
          <!-- Sidebar Navidation Menus--><span class="heading">Main</span>
          <ul class="list-unstyled">
            <li class="active"> <a href="panel_pemilik.php"><i class="icon-home"></i>Home</a></li>
            <li> <a href="view_pemilik.php"> <i class="icon-grid"></i>View Data </a></li>
            <li> <a href="pelanggan.php"> <i class="icon-grid"></i>Data Penyewa</a></li>
            <li> <a href="form_pemilik.php"> <i class="icon-padnote"></i>Input Data Kos </a></li>
            <li> <a href="account_pemilik.php"> <i class="icon-interface-windows"></i>Account</a></li>
          </ul>
        </nav>
        
        <div class="content-inner">
          <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Dashboard</h2>
            </div>
          </header>
          <!-- Dashboard Counts Section-->
          <section class="forms"> 
            <div class="container-fluid">
              <div class="row">
                <!-- Basic Form-->
                <div class="col-lg-12">
                  <div class="card" id="panel-home">
                    <center><h2>Welcome <?php echo $_SESSION['username']; ?></h2></center>
                  </div>       
                </div>
              </div>
            </div>
          </section>

<?php include 'footer.php' ?>