<?php include 'header.php' ?>

    <div class="page-content d-flex align-items-stretch">
        <!-- Side Navbar -->
        <nav class="side-navbar">
          <!-- Sidebar Header-->
          <div class="sidebar-header d-flex align-items-center">
            <div class="avatar"><img src="img/avatar-1.jpg" alt="..." class="img-fluid rounded-circle"></div>
            <div class="title">
              <h1 class="h4"><?php echo $_SESSION['username']; ?></h1>
              <p><?php echo $_SESSION['status']; ?></p>
            </div>
          </div>
          <!-- Sidebar Navidation Menus--><span class="heading">Main</span>
          <ul class="list-unstyled">
            <li> <a href="panel_pemilik.php"><i class="icon-home"></i>Home</a></li>
            <li> <a href="view_pemilik.php"> <i class="icon-grid"></i>View Data </a></li>
            <li> <a href="pelanggan.php"> <i class="icon-grid"></i>Data Penyewa</a></li>
            <li class="active"> <a href="form_pemilik.php"> <i class="icon-padnote"></i>Input Data Kos </a></li>
            <li> <a href="account_pemilik.php"> <i class="icon-interface-windows"></i>Account</a></li>
          </ul>
        </nav>

		    <div class="content-inner">
          <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Forms Input Data Kos</h2>
            </div>
          </header>
          <!-- Forms Section-->
          <section class="forms"> 
            <div class="container-fluid">
              <div class="row">
                <!-- Basic Form-->
                <div class="col-lg-12">
                  <div class="card">
                    <div class="card-header d-flex align-items-center">
                      <h3 class="h4">Masukan data kos anda.</h3>
                    </div>
                    <div class="card-body">
                      <form method="POST" action="../php/input_data_kos.php" enctype="multipart/form-data">
                        <table class="table">
                          <tr>
                            <td>Nama Kos</td>
                            <td colspan="2"><input type="text" required placeholder="Nama kos" class="form-control" name="nama"></td>
                          </tr>
                          <tr>
                            <td>Alamat kos</td>
                            <td colspan="2"><textarea required placeholder="Alamat Kos" class="form-control" name="alamat"></textarea></td>
                          </tr>
                          <tr>
                            <td>Jumlah Kamar</td>
                            <td colspan="2"><input type="text" required placeholder="Jumlah Kamar Yang Kosong" class="form-control" name="jml_kamar"></td>
                          </tr>
                          <tr>
                            <td>Kamar Mandi</td>
                            <td colspan="2"><input type="text" required placeholder="Kamar Mandi" class="form-control" name="wc"></td>
                          </tr>
                          <tr>
                            <td rowspan="3">Harga Per Tahun</td>
                            <td width="80">1 Bulan</td>
                            <td><input type="text" class="form-control" name="1bulan" placeholder="Masukan Harga"></td>
                          </tr>
                          <tr>
                            <td width="80">6 Bulan</td>
                            <td><input type="text" class="form-control" name="6bulan" placeholder="Masukan Harga"></td>
                          </tr>
                          <tr>
                            <td width="80">1 Tahun</td>
                            <td><input type="text" class="form-control" name="1tahun" placeholder="Masukan Harga"></td>
                          </tr>
                          <tr>
                            <td rowspan="3">Fasilitas</td>
                            <td colspan="2"><input type="checkbox" name="FasilitasA" value=" AC "> AC</td>
                          </tr>
                          <tr>
                            <td colspan="2"><input type="checkbox" name="FasilitasW" value=" Lemari "> Lemari</td>
                          </tr>
                          <tr>
                            <td colspan="2"><input type="checkbox" name="FasilitasK" value=" Kasur "> Kasur</td>
                          </tr>
                          <tr>
                            <td>Foto Kos</td>
                            <td colspan="2"><input type="file" name="upload"></td>
                          </tr>
                          <tr>
                            <td colspan="3"><input type="submit" class="btn btn-success btn-block" name="submit" value="submit"></td>
                          </tr>
                        </table>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

<?php include 'footer.php' ?>