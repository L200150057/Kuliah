<?php include 'header.php' ?>

    <div class="page-content d-flex align-items-stretch">
        <!-- Side Navbar -->
        <nav class="side-navbar">
          <!-- Sidebar Header-->
          <div class="sidebar-header d-flex align-items-center">
            <div class="avatar"><img src="img/avatar-1.jpg" alt="..." class="img-fluid rounded-circle"></div>
            <div class="title">
              <h1 class="h4"><?php echo $_SESSION['username']; ?></h1>
              <p><?php echo $_SESSION['status']; ?></p>
            </div>
          </div>
          <!-- Sidebar Navidation Menus--><span class="heading">Main</span>
          <ul class="list-unstyled">
            <li> <a href="panel_penyewa.php"><i class="icon-home"></i>Home</a></li>
            <li> <a href="cari_kos.php"> <i class="icon-grid"></i>Cari Kos</a></li>
            <!-- <li> <a href="charts.html"> <i class="fa fa-bar-chart"></i>Charts </a></li> -->
            <li class="active"> <a href="form_penyewa.php"> <i class="icon-padnote"></i>Cek Kos</a></li>
            <li> <a href="account_penyewa.php"> <i class="icon-interface-windows"></i>Account</a></li>
          </ul>
        </nav>

		    <div class="content-inner">
          <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Data Kos yang anda minati</h2>
            </div>
          </header>
          <!-- Forms Section-->
          <section class="forms"> 
            <div class="container-fluid">
              <div class="row">
                <!-- Basic Form-->
                <?php

                  include '../php/connect.php';

                  $sql = "select * from transaksi";
                  $query = mysqli_query($con, $sql);

                  while ($data = mysqli_fetch_array($query, MYSQLI_ASSOC)){

                    $id_kos = $data['id_kos'];
                    $id_user = $data['id_pemilik'];  

                    $sql_user = "select email, telp from user where id_user='$id_user'";
                    $query_user = mysqli_query($con, $sql_user);
                    $data_user = mysqli_fetch_array($query_user, MYSQLI_ASSOC);

                    $sql1 = "select * from data_kos where id_kos='$id_kos'";
                    $query1 = mysqli_query($con, $sql1);
                    $data1 = mysqli_fetch_array($query1, MYSQLI_ASSOC);

                      echo '
                        <div class="col-lg-12">
                          <div class="card">
                            <div class="card-header d-flex align-items-center">
                              <h3 class="h4">Data Kos '.$data1["nama_kos"].'</h3>
                            </div>
                            <div class="card-body">
                            <div class="card-close">
                            <div class="dropdown">
                                <button type="button" id="closeCard1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-ellipsis-v"></i></button>
                                <div aria-labelledby="closeCard1" class="dropdown-menu dropdown-menu-right has-shadow"><a href="../php/delete_sewa.php?id_kos='.$id_kos.'" class="dropdown-item edit"> <i class="fa fa-gear"></i>Delete</a></div>
                            </div>
                            </div>
                              <table class="table table-bordered">
                                <tr>
                                  <td colspan="2" id="gambar-table"><img src="../admin/img/'.$data1["foto"].'"></img></td>
                                </tr>
                                <tr>
                                  <td>Alamat kos</td>
                                  <td>'.$data1["alamat_kos"].'</td>
                                </tr>
                                <tr>
                                  <td>Fasilitas</td>
                                  <td>'.$data1["fasilitas"].'</td>
                                </tr>
                                <tr>
                                  <td>Kamar Mandi</td>
                                  <td>'.$data1["wc"].'</td>
                                </tr>
                                <tr>
                                  <td>Harga 1 Bulan</td>
                                  <td>'.$data1["1bln"].'</td>
                                </tr>
                                <tr>
                                  <td>Harga 6 Bulan</td>
                                  <td>'.$data1["6bln"].'</td>
                                </tr>
                                <tr>
                                  <td>Harga 1 Tahun</td>
                                  <td>'.$data1["1thn"].'</td>
                                </tr>
                                <tr>
                                  <td>Email Pemilik</td>
                                  <td>'.$data_user['email'].'</td>
                                </tr>
                                <tr>
                                  <td>No Telepon Pemilik</td>
                                  <td>'.$data_user['telp'].'</td>
                                </tr>
                              </table>
                            </div>
                          </div>
                        </div>
                      ';
                    
                  }
                  
                ?>
              </div>
            </div>
          </section>

<?php include 'footer.php' ?>