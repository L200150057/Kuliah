<?php include 'header.php' ?>

      <div class="page-content d-flex align-items-stretch">
        <!-- Side Navbar -->
        <nav class="side-navbar">
          <!-- Sidebar Header-->
          <div class="sidebar-header d-flex align-items-center">
            <div class="avatar"><img src="img/avatar-1.jpg" alt="..." class="img-fluid rounded-circle"></div>
            <div class="title">
              <h1 class="h4"><?php echo $_SESSION['username']; ?></h1>
              <p><?php echo $_SESSION['status']; ?></p>
            </div>
          </div>
          <!-- Sidebar Navidation Menus--><span class="heading">Main</span>
          <ul class="list-unstyled">
            <li> <a href="panel_pemilik.php"><i class="icon-home"></i>Home</a></li>
            <li class="active"> <a href="view_pemilik.php"> <i class="icon-grid"></i>View Data </a></li>
            <li> <a href="pelanggan.php"> <i class="icon-grid"></i>Data Penyewa</a></li>
            <li> <a href="form_pemilik.php"> <i class="icon-padnote"></i>Input Data Kos </a></li>
            <li> <a href="account_pemilik.php"> <i class="icon-interface-windows"></i>Account</a></li>
          </ul>
        </nav>

		    <div class="content-inner">
          <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">View Data Kos Anda</h2>
            </div>
          </header>
          <section class="forms"> 
            <div class="container-fluid">
              <div class="row">
                <!-- Basic Form-->
                <div class="col-lg-12">
                      <?php

                        include '../php/connect.php';
                        $user = $_SESSION['username'];
                        $sql = "select * from data_kos where id_user='$user'";
                        $query = mysqli_query($con, $sql);
                        while ($data = mysqli_fetch_array($query, MYSQLI_ASSOC)){
                          echo '
                          <div class="card">
                          <div class="card-header d-flex align-items-center">
                            <h3 class="h4">Data Kos '.$data["nama_kos"].'</h3>
                          </div>
                          <div class="card-body">
                          <div class="card-close">
                          <div class="dropdown">
                            <button type="button" id="closeCard1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-ellipsis-v"></i></button>
                            <div aria-labelledby="closeCard1" class="dropdown-menu dropdown-menu-right has-shadow">
                            <a href="edit_data_kos.php?kos='.$data["nama_kos"].'" class="dropdown-item edit"><i class="fa fa-gear">
                            </i>Edit</a>
                            <a href="../php/delete_kos.php?kos='.$data["nama_kos"].'" class="dropdown-item edit"><i class="fa fa-gear">
                            </i>Delete</a>
                            </div>

                          </div>
                          </div>
                            <table class="table table-bordered">
                              <tr>
                                <td colspan="2" id="gambar-table"><img src="../admin/img/'.$data["foto"].'"></img></td>
                              </tr>
                              <tr>
                                <td>Nama kos</td>
                                <td>'.$data["nama_kos"].'</td>
                              </tr>
                              <tr>
                                <td>Alamat kos</td>
                                <td>'.$data["alamat_kos"].'</td>
                              </tr>
                              <tr>
                                <td>Fasilitas</td>
                                <td>'.$data["fasilitas"].'</td>
                              </tr>
                              <tr>
                                <td>Kamar Mandi</td>
                                <td>'.$data["wc"].'</td>
                              </tr>
                              <tr>
                                <td>Harga 1 Bulan</td>
                                <td>'.$data["1bln"].'</td>
                              </tr>
                              <tr>
                                <td>Harga 6 Bulan</td>
                                <td>'.$data["6bln"].'</td>
                              </tr>
                              <tr>
                                <td>Harga 1 Tahun</td>
                                <td>'.$data["1thn"].'</td>
                              </tr>
                            </table>
                            </div>
                            </div>
                          ';  
                        }
                        

                      ?>                    
                </div>
              </div>
            </div>
          </section>

<?php include 'footer.php' ?>