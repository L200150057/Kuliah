<?php

	include 'connect.php';

	session_start();
	

	$nama = $_POST['nama'];
	$alamat = $_POST['alamat'];
	$fasilitas = $_POST['fasilitas'];
	$wc = $_POST['wc'];
	$satu = $_POST['1bln'];
	$enam = $_POST['6bln'];
	$satut = $_POST['1thn'];
	$kos = $_GET['kos'];

	$query = "update data_kos set nama_kos='$nama', alamat_kos='$alamat', fasilitas='$fasilitas', wc='$wc', 1bln='$satu', 6bln='$enam', 1thn='$satut' where nama_kos='$kos'";
	mysqli_query($con, $query);
	echo '
		<script>
			alert("Data Anda Sudah Di Update");
			document.location="../admin/view_pemilik.php";
		</script>
	';

?>