<?php
	include 'connect.php';
	session_start();
	$penyewa = $_SESSION['username'];
	$id_pemilik = $_GET['id_user'];
	$id_kos = $_GET['id_kos'];

	$query = "insert into transaksi values ('', '$id_pemilik', '$id_kos', '$penyewa')";
	mysqli_query($con, $query);

	echo '
		<script>
			alert("data telah di tambahkan");
			document.location="../admin/cari_kos.php";
		</script>
	'
?>