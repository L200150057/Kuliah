<?php

	include 'connect.php';
	$id = $_GET['user'];
	$id_user = $_POST['id_user'];
	$pass = $_POST['password'];
	$nama = $_POST['nama'];
	$email = $_POST['email'];
	$telp = $_POST['telp'];
	$alamat = $_POST['alamat'];
	$nik = $_POST['nik'];

	session_start();
	$_SESSION['username'] = $id_user;
	$status = $_SESSION['status'];

	$query = "update user set id_user='$id_user', password='$pass', email='$email', nama='$nama', telp='$telp', NIK='$nik', alamat='$alamat' where id_user='$id'";
	mysqli_query($con, $query);

	if($status == "Pemilik"){
		echo '
		<script>
			alert("data anda sudah di update");
			document.location="../admin/account_pemilik.php";
		</script>
		';
	}elseif ($status == "Penyewa") {
		echo '
		<script>
			alert("data anda sudah di update");
			document.location="../admin/account_penyewa.php";
		</script>
		';
	}	

?>