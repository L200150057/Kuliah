<?php
	session_start();
	echo "selamat datang ".$_SESSION['username'];
?>

<!DOCTYPE html>
<html>
<head>
	<title>Admin Panel</title>
</head>
<body>

</body>
</html>