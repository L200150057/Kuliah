<?php
	session_start();
	error_reporting(E_ALL ^ E_NOTICE);
	include 'connect.php';

	$id_user = $_SESSION['username'];
	$namakos = $_POST['nama'];
	$alamatkos = $_POST['alamat'];
	$kamar = $_POST['jml_kamar'];
	$fasilitasa = $_POST['FasilitasA'];
	$fasilitask = $_POST['FasilitasK'];
	$fasilitasw = $_POST['FasilitasW'];
	$fasilitas = $fasilitasa.$fasilitask.$fasilitasw;
	$wc = $_POST['wc'];
	$bulan1 = $_POST['1bulan'];
	$bulan6 = $_POST['6bulan'];
	$tahun1 = $_POST['1tahun'];
	$direktori = '../admin/img/';
	$nama_foto = $_FILES['upload']['name'];
	$upload = $direktori.$nama_foto;


	move_uploaded_file($_FILES['upload']['tmp_name'], $upload);

	$query = "INSERT INTO data_kos (id_kos, nama_kos, alamat_kos, fasilitas, wc, 1bln, 6bln, 1thn, foto, id_user) 
	VALUES('','$namakos','$alamatkos','$fasilitas','$wc','$bulan1','$bulan6','$tahun1', '$nama_foto', '$id_user')";

	$a = mysqli_query($con, $query);
	echo '
	<script>
		alert("data anda sudah ditambahkan");
		document.location="../admin/form_pemilik.php";
	</script>
	';
?>