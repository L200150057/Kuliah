<?php
	include 'connect.php';

	$id_kos = $_GET['id_kos'];

	$query = "delete from transaksi where id_kos='$id_kos'";
	mysqli_query($con, $query);

	echo '
		<script>
			alert("Data telah di delete");
			document.location="../admin/form_penyewa.php"
		</script>
	';
?>