<?php
	include 'connect.php';
	$user = $_POST['username'];
	$pass = $_POST['password'];
	$nama = $_POST['nama'];
	$email = $_POST['email'];
	$telp = $_POST['telp'];
	$alamat = $_POST['alamat'];
	$nik = $_POST['nik'];
	$status = $_POST['status'];

	$query = "insert into user values ('$user', '$pass', '$email', '$nama', '$telp', '$nik', '$alamat', '$status')";
	mysqli_query($con, $query);
	echo "<script>
	alert('data anda sudah ditambahkan');
	</script>";
	echo "<center><a href='../login.html'> Klik disini untuk login </a></center>";
?>