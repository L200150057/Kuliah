<?php

	include 'connect.php';

	session_start();

	$kos = $_GET['kos'];

	$query = "delete from data_kos where nama_kos='$kos'";
	mysqli_query($con, $query);
	echo '
		<script>
			alert("Data Anda Sudah Di Delete");
			document.location="../admin/view_pemilik.php";
		</script>
	';

?>