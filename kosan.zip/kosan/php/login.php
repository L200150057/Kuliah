<?php
	include 'connect.php';

	session_start();

	$user = $_POST['username'];
	$pass = $_POST['password'];
	
	$sql = "select * from user where id_user='$user' and password='$pass'";
	$query = mysqli_query($con, $sql);
	$row = mysqli_fetch_array($query, MYSQLI_ASSOC);

	if($row['id_user'] != ''){

		$_SESSION['username'] = $row['id_user'];
		$_SESSION['password'] = $row['password'];
		$_SESSION['status'] = $row['status'];

		if($row['status'] == 'Pemilik'){
			echo '
			<script>
				alert("Anda Berhasil Login");
				document.location = "../admin/panel_pemilik.php";
			</script>
			';
		}
		elseif($row['status'] == 'Penyewa'){
			echo '
			<script>
				alert("Anda Berhasil Login");
				document.location = "../admin/panel_penyewa.php";
			</script>
			';
		}
	}else{
		echo '
		<script>
			alert("anda gagal login");
			document.location="../login.php";
		</script>
		';
	}
?>