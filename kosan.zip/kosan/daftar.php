<?php include 'header.php'; ?>

<body>
	<!-- Header -->
	<div class="tm-header">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-4 col-sm-3 tm-site-name-container">
					<a href="#" class="tm-site-name">Holiday</a>	
				</div>
				<div class="col-lg-6 col-md-8 col-sm-9">
					<div class="mobile-menu-icon">
						<i class="fa fa-bars"></i>
					</div>
					<nav class="tm-nav">
						<ul>
							<li><a href="index.php" >Home</a></li>
							<li><a href="about.php">About</a></li>
							<li><a href="daftar.php" class="active">Daftar</a></li>
							<li><a href="login.php">Login</a></li>
						</ul>
					</nav>		
				</div>				
			</div>
		</div>	  	
	</div>

	<!-- Banner -->
	<section class="tm-banner">
		<!-- Flexslider -->
		<div class="flexslider flexslider-banner">
		  <ul class="slides">
		    <li>
			    <div class="tm-banner-inner">
					<h1 class="tm-banner-title">Anda<span class="tm-yellow-text"> Harus </span>Daftar</h1>
					<p class="tm-banner-subtitle">Untuk menagakses situs ini sepenuhnya</p>
					<a href="#more" class="tm-banner-link">Sign Up Here</a>	
				</div>
				<img src="img/banner-3.jpg" alt="Banner 3" />	
		    </li>		    
		  </ul>
		</div>	
	</section>

	<!-- gray bg -->	
	<section class="container tm-home-section-1" id="more">
		<div class="row">
			<!-- slider -->
			<div class="flexslider effect2 effect2-contact tm-contact-box-1">
				<div class="row" id="tulisan-garis">				
					<div class="tm-section-header">
						<div class="col-lg-3 col-md-3 col-sm-3"><hr></div>
						<div class="col-lg-6 col-md-6 col-sm-6"><h2 class="tm-section-title">Sign Up</h2></div>
						<div class="col-lg-3 col-md-3 col-sm-3"><hr></div>	
					</div>
				</div>
				<ul class="slides">
					<form method="POST" action="php/signup.php">
					  <div class="form-row">
					    <div class="form-group col-md-6">
					      <label>Username</label>
					      <input type="text" class="form-control" name="username" placeholder="Username" required="">
					    </div>
					    <div class="form-group col-md-6">
					      <label>Password</label>
					      <input type="password" class="form-control" name="password" placeholder="Password" required="">
					    </div>
					  </div>
					  <div class="form-group col-md-12">
					    <label>Nama Lengkap</label>
					    <input type="text" class="form-control" name="nama" placeholder="Your full Name" required="">
					  </div>
					  <div class="form-group col-md-12">
					    <label>E-Mail</label>
					    <input type="email" class="form-control" name="email" placeholder="Your E-Mail" required="">
					  </div>
					  <div class="form-group col-md-12">
					    <label>No Telp</label>
					    <input type="text" class="form-control" name="telp" placeholder="Your Number" required="">
					  </div>
					  <div class="form-group col-md-12">
					    <label>Alamat</label>
					    <textarea class="form-control" name="alamat" placeholder="Apartment, studio, or floor" required=""></textarea>
					  </div>
					  <div class="form-row">
					    <div class="form-group col-md-6">
					      <label>NIK</label>
					      <input type="text" class="form-control" name="nik" required="">
					    </div>
					    <div class="form-group col-md-6">
					      <label for="inputState">State</label>
					      <select name="status" class="form-control" required="">
					        <option value="Penyewa">Penyewa</option>
					        <option value="Pemilik">Pemilik</option>
					      </select>
					    </div>
					    <div class="form-group col-md-6">
					    	<button type="submit" class="btn btn-primary">Sign in</button>
					    </div>
					  </div>
					</form>
				</ul>
			</div>
		</div>
	</section>		
	
	<?php include 'footer.php' ?>
