<?php include 'header.php'; ?>

  <body class="tm-gray-bg">
  	<!-- Header -->
  	<div class="tm-header">
  		<div class="container">
  			<div class="row">
  				<div class="col-lg-6 col-md-4 col-sm-3 tm-site-name-container">
  					<a href="#" class="tm-site-name">Holiday</a>	
  				</div>
	  			<div class="col-lg-6 col-md-8 col-sm-9">
	  				<div class="mobile-menu-icon">
		              <i class="fa fa-bars"></i>
		            </div>
	  				<nav class="tm-nav">
						<ul>
							<li><a href="index.php" class="active">Home</a></li>
							<li><a href="about.php">About</a></li>
							<li><a href="daftar.php">Daftar</a></li>
							<li><a href="login.php">Login</a></li>
						</ul>
					</nav>		
	  			</div>				
  			</div>
  		</div>	  	
  	</div>
	
	<!-- Banner -->
	<section class="tm-banner">
		<!-- Flexslider -->
		<div class="flexslider flexslider-banner">
		  <ul class="slides">
		    <li>
			    <div class="tm-banner-inner">
					<h1 class="tm-banner-title">Cari <span class="tm-yellow-text">Tempat</span> Terbaik</h1>
					<p class="tm-banner-subtitle">Untuk Ngekos</p>
					<a href="#more" class="tm-banner-link">Learn More</a>	
				</div>
				<img src="img/banner-1.jpg" alt="Image" />	
		    </li>
		    <li>
			    <div class="tm-banner-inner">
					<h1 class="tm-banner-title">Cari <span class="tm-yellow-text">Kos</span> Impianmu</h1>
					<p class="tm-banner-subtitle">Cari disini</p>
					<a href="#more" class="tm-banner-link">Learn More</a>	
				</div>
		      <img src="img/banner-2.jpg" alt="Image" />
		    </li>
		    <li>
			    <div class="tm-banner-inner">
					<h1 class="tm-banner-title">Cari <span class="tm-yellow-text">Kos</span> Murah</h1>
					<p class="tm-banner-subtitle">Hanya di sini</p>
					<a href="#more" class="tm-banner-link">Learn More</a>	
				</div>
		      <img src="img/banner-3.jpg" alt="Image" />
		    </li>
		  </ul>
		</div>	
	</section>

	<!-- gray bg -->	
	<section class="container tm-home-section-1">
	
		<div class="section-margin-top" id="more">
			<div class="row" id="tulisan-garis">				
				<div class="tm-section-header">
					<div class="col-lg-3 col-md-3 col-sm-3"><hr></div>
					<div class="col-lg-6 col-md-6 col-sm-6"><h2 class="tm-section-title">Rekomendasi</h2></div>
					<div class="col-lg-3 col-md-3 col-sm-3"><hr></div>	
				</div>
			</div>
			<div class="row">
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 col-xxs-12">
					<div class="tm-home-box-2">						
						<img src="img/index-03.jpg" alt="image" class="img-responsive">
						<cenTer><h3>kos Merdeka</h3></center>
						<center  id="sewa"><a class="btn btn-success btn-block" href="daftar.php">sewa</a></center>
						
					</div>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 col-xxs-12">
					<div class="tm-home-box-2">						
					    <img src="img/index-04.jpg" alt="image" class="img-responsive">
						<cenTer><h3>kos Maharani</h3></center>
						<center  id="sewa"><a class="btn btn-success btn-block" href="daftar.php">sewa</a></center>
						
					</div>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 col-xxs-12">
					<div class="tm-home-box-2">						
					    <img src="img/index-05.jpg" alt="image" class="img-responsive">
						<cenTer><h3>kos Nevada</h3></center>
						<center  id="sewa"><a class="btn btn-success btn-block" href="daftar.php">sewa</a></center>
						
					</div>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 col-xxs-12">
					<div class="tm-home-box-2 tm-home-box-2-right">						
					    <img src="img/index-06.jpg" alt="image" class="img-responsive">
						<cenTer><h3>kos Mahadewi</h3></center>
						<center  id="sewa"><a class="btn btn-success btn-block" href="daftar.php">sewa</a></center>
						
					</div>
				</div>
			</div>
			
		</div>
	</section>

	<?php include 'footer.php' ?>